
<!DOCTYPE html>
<html>
  <body>

    <!-- [SEARCH FORM] -->
    <form method="post" action="../Controller/findProduct.php">
      <h1>SEARCH FOR PRODUCT</h1>
      <input type="text" name="product_name" />
      <input type="submit" name="findProduct" value="Search"/>
    </form>


 
  </body>
</html>