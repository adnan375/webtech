<!DOCTYPE html>
<html>
<head>
	<title>Contact us</title>
  <?php include_once 'header.php' ?>
</head>

<body>
 <div>
 	   <h3 style="color: red; " align="center">Contact us</h3>
 </div>

 <table>
  
  <tr>
    <td>Title</td>
    <td>Details</td>
   
  </tr>
  <tr>
    <td>Name</td>
    <td>Steven Spielberg</td>

  </tr>
  <tr>
    <td>Number</td>
    <td>01787092919</td>

  </tr>
  <tr>
    <td>E-mail</td>
    <td>info@restaurent.com</td>

  </tr>
  <tr>
    <td>Address</td>
    <td>Sector:18, Uttara, Dhaka</td>

  </tr>
</table>

  <?php include_once 'footer.php' ?>

</body>
</html>