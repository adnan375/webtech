<fieldset>
    <center>
        <b>
            <label>
                Copyright © 2017
            </label>
        </b>
    </center>
</fieldset>