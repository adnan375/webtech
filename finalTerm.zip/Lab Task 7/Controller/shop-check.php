<?php  
require_once '../controller/product-info.php';

$products = fetchAllProducts();


?>