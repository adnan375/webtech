<!DOCTYPE html>
<html>
<head>
	<title>Contact us</title>
  <?php include_once 'header.php' ?>
  <link rel="stylesheet" href="../style.css">
</head>

<body>
 <div>
 	   <h3 class="title">Contact us</h3>
 </div>

 <table>
  
  <tr>
    <td>Title</td>
    <td>Details</td>
   
  </tr>
  <tr>
    <td>Name</td>
    <td>Francisco Chang</td>

  </tr>
  <tr>
    <td>Number</td>
    <td>+8801787092919</td>

  </tr>
  <tr>
    <td>E-mail</td>
    <td> Restaurentfood@.com</td>

  </tr>
  <tr>
    <td>Address</td>
    <td>10 Road,Uttara, Dhaka</td>

  </tr>
</table>

  <?php include_once 'footer.php' ?>

</body>
</html>