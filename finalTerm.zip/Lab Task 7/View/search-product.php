
<form action="../Controller/find-product.php" method="post">

	<input type="text" placeholder="Search.." name="productName">
	<input type="submit" name="findProduct" value="Search">

</form>